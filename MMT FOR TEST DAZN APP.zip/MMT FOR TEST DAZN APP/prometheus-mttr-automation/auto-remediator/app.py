from flask import Flask, request, jsonify
import logging
import time

app = Flask(__name__)

# Configure logging to output to Docker logs
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def execute_remediation(alert):
    """
    Map alert labels to automated actions.
    This is where you write scripts to restart services, clear caches, or scale instances.
    """
    alert_name = alert.get('labels', {}).get('alertname', 'Unknown')
    action = alert.get('labels', {}).get('action', 'none')
    instance = alert.get('labels', {}).get('instance', 'Unknown')
    status = alert.get('status', 'firing')

    if status == 'resolved':
        logger.info(f"✅ Alert {alert_name} resolved for {instance}. No action needed.")
        return

    logger.warning(f"🚨 FIRING: {alert_name} on {instance}. Action required: {action}")

    if action == 'restart_service':
        logger.info(f"⚙️ EXECUTING RUNBOOK: Restarting service on {instance}...")
        time.sleep(2) # Simulate work
        logger.info("✅ SUCCESS: Service restarted. MTTR reduced to seconds.")
    
    elif action == 'scale_up':
        logger.info(f"⚙️ EXECUTING RUNBOOK: Triggering auto-scaling group for {instance}...")
        time.sleep(2) # Simulate work
        logger.info("✅ SUCCESS: Additional nodes provisioned.")
        
    else:
        logger.info(f"⚠️ No automated runbook found for action: {action}. Escalating to human on-call.")

@app.route('/webhook', methods=['POST'])
def webhook():
    """Endpoint that Alertmanager hits when an alert fires."""
    data = request.json
    
    if data and 'alerts' in data:
        for alert in data['alerts']:
            execute_remediation(alert)
            
    return jsonify({"status": "success", "message": "Webhook processed"}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)